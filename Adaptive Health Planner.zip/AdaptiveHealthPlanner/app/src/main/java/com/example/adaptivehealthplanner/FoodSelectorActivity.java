package com.example.adaptivehealthplanner;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class FoodSelectorActivity extends AppCompatActivity {

    private AutoCompleteTextView autoBreakfast, autoLunch, autoDinner;
    private DatabaseHelper dbHelper;
    private List<FoodItem> fullFoodList = new ArrayList<>();
    private List<String> foodNames = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_selector);

        dbHelper = new DatabaseHelper(this);

        autoBreakfast = findViewById(R.id.auto_breakfast);
        autoLunch = findViewById(R.id.auto_lunch);
        autoDinner = findViewById(R.id.auto_dinner);
        
        Button btnTrack = findViewById(R.id.btn_track_macros);
        ImageButton btnBack = findViewById(R.id.btn_back_to_profile);
        Button btnUpdateInfo = findViewById(R.id.btn_update_info);

        loadAllFoodData();

        btnBack.setOnClickListener(v -> {
            Intent intent = new Intent(this, ProfileActivity.class);
            intent.putExtra("edit_mode", true);
            startActivity(intent);
        });

        btnUpdateInfo.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));

        btnTrack.setOnClickListener(v -> {
            if (validateSelections()) {
                saveSelectedMeals();
                startActivity(new Intent(this, MainActivity.class));
            } else {
                Toast.makeText(this, "Please search and select valid food items", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadAllFoodData() {
        // Fetch ALL foods for search engine
        Cursor cursor = dbHelper.getReadableDatabase().query(DatabaseHelper.TABLE_FOOD, null, null, null, null, null, DatabaseHelper.COL_FOOD_NAME + " ASC");
        
        fullFoodList.clear();
        foodNames.clear();
        
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_FOOD_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_FOOD_NAME));
                float cal = cursor.getFloat(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_CALORIES));
                float p = cursor.getFloat(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_PROTEIN));
                float c = cursor.getFloat(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_CARBS));
                float f = cursor.getFloat(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_FAT));
                
                fullFoodList.add(new FoodItem(id, name, cal, p, c, f));
                foodNames.add(name);
            } while (cursor.moveToNext());
            cursor.close();
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, foodNames);
        
        autoBreakfast.setAdapter(adapter);
        autoLunch.setAdapter(adapter);
        autoDinner.setAdapter(adapter);
    }

    private boolean validateSelections() {
        return foodNames.contains(autoBreakfast.getText().toString()) &&
               foodNames.contains(autoLunch.getText().toString()) &&
               foodNames.contains(autoDinner.getText().toString());
    }

    private void saveSelectedMeals() {
        String today = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(new java.util.Date());
        
        logMeal(today, "Breakfast", autoBreakfast.getText().toString());
        logMeal(today, "Lunch", autoLunch.getText().toString());
        logMeal(today, "Dinner", autoDinner.getText().toString());
        
        Toast.makeText(this, "Meals Logged!", Toast.LENGTH_SHORT).show();
    }

    private void logMeal(String date, String type, String name) {
        for (FoodItem item : fullFoodList) {
            if (item.name.equals(name)) {
                dbHelper.logFood(date, item.id, type, item.cal, item.p, item.c, item.f);
                break;
            }
        }
    }

    private static class FoodItem {
        int id; String name; float cal, p, c, f;
        FoodItem(int id, String name, float cal, float p, float c, float f) {
            this.id = id; this.name = name; this.cal = cal; this.p = p; this.c = c; this.f = f;
        }
    }
}
