package com.example.adaptivehealthplanner;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class Historyadapter extends RecyclerView.Adapter<Historyadapter.PlanViewHolder> {

    private List<Healthplan> currentList = new ArrayList<>();

    public static class PlanViewHolder extends RecyclerView.ViewHolder {
        final TextView tvDate;
        final TextView tvWorkout;
        final TextView tvDiet;
        final TextView tvWater;

        PlanViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDate    = itemView.findViewById(R.id.tv_item_date);
            tvWorkout = itemView.findViewById(R.id.tv_item_workout);
            tvDiet    = itemView.findViewById(R.id.tv_item_diet);
            tvWater   = itemView.findViewById(R.id.tv_item_water);
        }
    }

    @NonNull
    @Override
    public PlanViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_plan_card, parent, false);
        return new PlanViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PlanViewHolder holder, int position) {
        Healthplan plan = currentList.get(position);
        holder.tvDate.setText(plan.date);
        holder.tvDiet.setText(String.format("Diet: %s", plan.diet));
        holder.tvWorkout.setText(String.format("Workout: %s", plan.workout));
        holder.tvWater.setText(String.format("Water: %s", plan.water));
    }

    @Override
    public int getItemCount() {
        return currentList.size();
    }

    @Override
    public long getItemId(int position) {
        return currentList.get(position).id;
    }

    public void submitList(List<Healthplan> newList) {
        List<Healthplan> safeNew = new ArrayList<>(newList);
        DiffUtil.DiffResult result = DiffUtil.calculateDiff(new Plandiffcallback(currentList, safeNew));
        currentList = safeNew;
        result.dispatchUpdatesTo(this);
    }
}
