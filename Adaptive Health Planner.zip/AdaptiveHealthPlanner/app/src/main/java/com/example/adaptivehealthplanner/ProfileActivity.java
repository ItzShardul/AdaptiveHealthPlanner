package com.example.adaptivehealthplanner;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;
import java.util.Locale;

public class ProfileActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    private EditText etName, etAge, etWeight, etHeight;
    private Spinner spinnerGoal, spinnerGender, spinnerBlood, spinnerWeightUnit, spinnerHeightUnit;
    private RadioGroup rgFood;
    private ImageView ivProfile;
    private Uri imageUri;
    private SharedPreferences sharedPreferences;
    private boolean isEditMode = false;
    
    private String lastWeightUnit = "Kg";
    private String lastHeightUnit = "cm";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        sharedPreferences = getSharedPreferences("UserProfile", MODE_PRIVATE);
        isEditMode = getIntent().getBooleanExtra("edit_mode", false);

        if (sharedPreferences.contains("name") && !isEditMode) {
            startActivity(new Intent(ProfileActivity.this, FoodSelectorActivity.class));
            finish();
            return;
        }

        setContentView(R.layout.activity_profile);

        etName = findViewById(R.id.et_name);
        etAge = findViewById(R.id.et_age);
        etWeight = findViewById(R.id.et_weight);
        etHeight = findViewById(R.id.et_height);
        spinnerGoal = findViewById(R.id.spinner_goal);
        spinnerGender = findViewById(R.id.spinner_gender);
        spinnerBlood = findViewById(R.id.spinner_blood);
        spinnerWeightUnit = findViewById(R.id.spinner_weight_unit);
        spinnerHeightUnit = findViewById(R.id.spinner_height_unit);
        rgFood = findViewById(R.id.rg_food);
        ivProfile = findViewById(R.id.iv_profile_pic);
        Button btnPickImage = findViewById(R.id.btn_pick_image);
        Button btnSave = findViewById(R.id.btn_save_profile);

        setupUnitConverters();

        if (isEditMode) {
            loadExistingData();
        }

        btnPickImage.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");
            startActivityForResult(intent, PICK_IMAGE_REQUEST);
        });

        btnSave.setOnClickListener(v -> saveProfile());
    }

    private void setupUnitConverters() {
        spinnerWeightUnit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String currentUnit = parent.getItemAtPosition(position).toString();
                String weightVal = etWeight.getText().toString();
                
                if (!weightVal.isEmpty() && !currentUnit.equals(lastWeightUnit)) {
                    float val = Float.parseFloat(weightVal);
                    if (currentUnit.equals("lbs")) {
                        val = val * 2.20462f;
                    } else {
                        val = val / 2.20462f;
                    }
                    etWeight.setText(String.format(Locale.US, "%.2f", val));
                }
                lastWeightUnit = currentUnit;
                if (view != null) ((TextView) view).setTextColor(getResources().getColor(R.color.white));
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        spinnerHeightUnit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String currentUnit = parent.getItemAtPosition(position).toString();
                String heightVal = etHeight.getText().toString();

                if (!heightVal.isEmpty() && !currentUnit.equals(lastHeightUnit)) {
                    float val = Float.parseFloat(heightVal);
                    if (currentUnit.equals("Feet/Inches")) {
                        val = val / 30.48f;
                    } else {
                        val = val * 30.48f;
                    }
                    etHeight.setText(String.format(Locale.US, "%.2f", val));
                }
                lastHeightUnit = currentUnit;
                if (view != null) ((TextView) view).setTextColor(getResources().getColor(R.color.white));
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        AdapterView.OnItemSelectedListener colorFixListener = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (view != null) ((TextView) view).setTextColor(getResources().getColor(R.color.white));
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        };
        spinnerGoal.setOnItemSelectedListener(colorFixListener);
        spinnerGender.setOnItemSelectedListener(colorFixListener);
        spinnerBlood.setOnItemSelectedListener(colorFixListener);
    }

    private void loadExistingData() {
        etName.setText(sharedPreferences.getString("name", ""));
        etAge.setText(String.valueOf(sharedPreferences.getInt("age", 0)));
        etWeight.setText(String.valueOf(sharedPreferences.getFloat("weight", 0f)));
        etHeight.setText(String.valueOf(sharedPreferences.getFloat("height", 0f)));
        
        setSpinnerValue(spinnerGoal, sharedPreferences.getString("goal", ""), R.array.fitness_goals);
        setSpinnerValue(spinnerGender, sharedPreferences.getString("gender", ""), R.array.genders);
        setSpinnerValue(spinnerBlood, sharedPreferences.getString("blood", ""), R.array.blood_groups);
        
        String foodPref = sharedPreferences.getString("foodPref", "Veg");
        if (foodPref.equals("Non-Veg")) {
            rgFood.check(R.id.rb_nonveg);
        } else {
            rgFood.check(R.id.rb_veg);
        }

        String picUri = sharedPreferences.getString("profilePic", null);
        if (picUri != null) {
            imageUri = Uri.parse(picUri);
            ivProfile.setImageURI(imageUri);
        }
    }

    private void setSpinnerValue(Spinner spinner, String value, int arrayResId) {
        String[] array = getResources().getStringArray(arrayResId);
        int index = Arrays.asList(array).indexOf(value);
        if (index >= 0) {
            spinner.setSelection(index);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            final int takeFlags = data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION;
            getContentResolver().takePersistableUriPermission(imageUri, takeFlags);
            ivProfile.setImageURI(imageUri);
        }
    }

    private void saveProfile() {
        String name = etName.getText().toString().trim();
        String ageStr = etAge.getText().toString().trim();
        String weightStr = etWeight.getText().toString().trim();
        String heightStr = etHeight.getText().toString().trim();

        if (name.isEmpty() || ageStr.isEmpty() || weightStr.isEmpty() || heightStr.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        float weight = Float.parseFloat(weightStr);
        float height = Float.parseFloat(heightStr);
        
        if (spinnerWeightUnit.getSelectedItem().toString().equals("lbs")) {
            weight = weight / 2.20462f;
        }
        
        if (spinnerHeightUnit.getSelectedItem().toString().equals("Feet/Inches")) {
            height = height * 30.48f;
        }

        float bmi = weight / ((height / 100) * (height / 100));
        String bmiCategory = getBMICategory(bmi);

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("name", name);
        editor.putInt("age", Integer.parseInt(ageStr));
        editor.putFloat("weight", weight);
        editor.putFloat("height", height);
        editor.putFloat("bmiValue", bmi); // SAVE BMI VALUE
        editor.putString("goal", spinnerGoal.getSelectedItem().toString());
        editor.putString("gender", spinnerGender.getSelectedItem().toString());
        editor.putString("blood", spinnerBlood.getSelectedItem().toString());
        editor.putString("bmiCategory", bmiCategory);
        
        int selectedFoodId = rgFood.getCheckedRadioButtonId();
        RadioButton rbFood = findViewById(selectedFoodId);
        editor.putString("foodPref", rbFood.getText().toString());
        
        if (imageUri != null) {
            editor.putString("profilePic", imageUri.toString());
        }
        
        editor.apply();

        Toast.makeText(this, "Profile Saved! BMI: " + String.format(Locale.US, "%.1f", bmi), Toast.LENGTH_SHORT).show();
        if (isEditMode) {
            finish();
        } else {
            startActivity(new Intent(ProfileActivity.this, FoodSelectorActivity.class));
            finish();
        }
    }

    private String getBMICategory(float bmi) {
        if (bmi < 18.5) return "Underweight";
        if (bmi < 25) return "Normal";
        if (bmi < 30) return "Overweight";
        return "Obese";
    }
}
