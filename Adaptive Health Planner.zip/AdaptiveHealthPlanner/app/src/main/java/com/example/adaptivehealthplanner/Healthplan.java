package com.example.adaptivehealthplanner;

import java.util.Objects;

/**
 * Immutable data model for a single health plan entry.
 */
public final class Healthplan {

    public final long id;
    public final String date;
    public final String diet;
    public final String workout;
    public final String water;

    public Healthplan(long id, String date, String diet, String workout, String water) {
        this.id = id;
        this.date = date;
        this.diet = diet;
        this.workout = workout;
        this.water = water;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Healthplan)) return false;
        Healthplan that = (Healthplan) o;
        return id == that.id &&
                Objects.equals(date, that.date) &&
                Objects.equals(diet, that.diet) &&
                Objects.equals(workout, that.workout) &&
                Objects.equals(water, that.water);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, date, diet, workout, water);
    }
}
