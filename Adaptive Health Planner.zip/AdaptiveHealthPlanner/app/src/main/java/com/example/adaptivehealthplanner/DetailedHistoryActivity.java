package com.example.adaptivehealthplanner;

import android.app.AlertDialog;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ImageButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class DetailedHistoryActivity extends AppCompatActivity {

    private CalendarView calendarView;
    private TableLayout tableLogs;
    private TextView tvNoData;
    private View tableContainer;
    private Button btnClearLog;
    private DatabaseHelper dbHelper;
    private String selectedDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed_history);

        dbHelper = new DatabaseHelper(this);
        calendarView = findViewById(R.id.calendar_history);
        tableLogs = findViewById(R.id.tl_logs);
        tvNoData = findViewById(R.id.tv_no_data);
        tableContainer = findViewById(R.id.table_container);
        btnClearLog = findViewById(R.id.btn_clear_day_log);
        Button btnViewLogs = findViewById(R.id.btn_view_logs);
        ImageButton btnBack = findViewById(R.id.btn_back_history);

        Calendar cal = Calendar.getInstance();
        selectedDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(cal.getTime());

        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            Calendar selected = Calendar.getInstance();
            selected.set(year, month, dayOfMonth);
            selectedDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(selected.getTime());
            tableContainer.setVisibility(View.GONE);
            btnClearLog.setVisibility(View.GONE);
            tvNoData.setVisibility(View.GONE);
        });

        btnViewLogs.setOnClickListener(v -> loadTableData(selectedDate));
        
        btnClearLog.setOnClickListener(v -> {
            // PRACTICAL #6: Confirmation Dialog
            new AlertDialog.Builder(this)
                    .setTitle("Delete Logs")
                    .setMessage("Are you sure you want to clear the food logs for " + selectedDate + "?")
                    .setPositiveButton("Yes, Clear", (dialog, which) -> {
                        dbHelper.deleteLogsForDate(selectedDate);
                        loadTableData(selectedDate); 
                        Toast.makeText(this, "Logs deleted.", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        btnBack.setOnClickListener(v -> finish());
    }

    private void loadTableData(String date) {
        int childCount = tableLogs.getChildCount();
        if (childCount > 1) {
            tableLogs.removeViews(1, childCount - 1);
        }

        Cursor cursor = dbHelper.getLogsForDate(date);

        if (cursor != null && cursor.getCount() > 0) {
            tvNoData.setVisibility(View.GONE);
            tableContainer.setVisibility(View.VISIBLE);
            btnClearLog.setVisibility(View.VISIBLE);

            while (cursor.moveToNext()) {
                TableRow row = new TableRow(this);
                row.setBackgroundColor(Color.WHITE);

                row.addView(createTextView(cursor.getString(0), true));
                row.addView(createTextView(cursor.getString(1), false));
                row.addView(createTextView(String.format(Locale.US, "%.0f", cursor.getFloat(2)), false));
                row.addView(createTextView(String.format(Locale.US, "%.1f", cursor.getFloat(3)), false));
                row.addView(createTextView(String.format(Locale.US, "%.1f", cursor.getFloat(4)), false));
                row.addView(createTextView(String.format(Locale.US, "%.1f", cursor.getFloat(5)), false));

                tableLogs.addView(row);
            }
            cursor.close();
        } else {
            tableContainer.setVisibility(View.GONE);
            btnClearLog.setVisibility(View.GONE);
            tvNoData.setVisibility(View.VISIBLE);
        }
    }

    private TextView createTextView(String text, boolean isBold) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setPadding(20, 20, 20, 20);
        tv.setTextColor(Color.BLACK);
        if (isBold) tv.setTypeface(null, android.graphics.Typeface.BOLD);
        return tv;
    }
}
