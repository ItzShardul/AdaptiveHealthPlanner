package com.example.adaptivehealthplanner;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * Displays the user's plan history using a RecyclerView + DiffUtil.
 */
public class HistoryActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private Historyadapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        dbHelper = new DatabaseHelper(this);

        // ── Back Button ──────────────────────────────────────────────────
        ImageButton btnBack = findViewById(R.id.btn_back_history);
        btnBack.setOnClickListener(v -> finish());

        // ── RecyclerView setup ──────────────────────────────────────────────
        RecyclerView recyclerView = findViewById(R.id.rv_history);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new Historyadapter();
        adapter.setHasStableIds(true);
        recyclerView.setAdapter(adapter);

        // ── Clear button ────────────────────────────────────────────────────
        Button btnClear = findViewById(R.id.btn_clear_history);
        btnClear.setOnClickListener(v -> {
            dbHelper.clearAllPlans();
            adapter.submitList(new ArrayList<>());
            Toast.makeText(this, "History Cleared", Toast.LENGTH_SHORT).show();
        });

        loadPlans();
    }

    private void loadPlans() {
        List<Healthplan> plans = new ArrayList<>();
        Cursor cursor = dbHelper.getAllPlans();

        if (cursor != null) {
            try {
                if (cursor.moveToFirst()) {
                    int idIdx      = cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID);
                    int dateIdx    = cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DATE);
                    int dietIdx    = cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DIET);
                    int workoutIdx = cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WORKOUT);
                    int waterIdx   = cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WATER);

                    do {
                        plans.add(new Healthplan(
                                cursor.getLong(idIdx),
                                cursor.getString(dateIdx),
                                cursor.getString(dietIdx),
                                cursor.getString(workoutIdx),
                                cursor.getString(waterIdx)
                        ));
                    } while (cursor.moveToNext());
                }
            } finally {
                cursor.close();
            }
        }

        adapter.submitList(plans);
    }
}