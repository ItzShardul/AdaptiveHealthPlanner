package com.example.adaptivehealthplanner;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    private EditText etWeight;
    private Spinner spinnerGoal;
    private SharedPreferences sharedPreferences;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        sharedPreferences = getSharedPreferences("UserProfile", MODE_PRIVATE);
        dbHelper = new DatabaseHelper(this);

        etWeight = findViewById(R.id.et_update_weight);
        spinnerGoal = findViewById(R.id.spinner_update_goal);
        Button btnUpdate = findViewById(R.id.btn_update_settings);
        Button btnReset = findViewById(R.id.btn_logout);

        // Pre-fill
        etWeight.setText(String.valueOf(sharedPreferences.getFloat("weight", 70f)));
        
        btnUpdate.setOnClickListener(v -> {
            String weightStr = etWeight.getText().toString();
            if (weightStr.isEmpty()) {
                Toast.makeText(this, "Please enter weight", Toast.LENGTH_SHORT).show();
                return;
            }

            SharedPreferences.Editor editor = sharedPreferences.edit();
            float weight = Float.parseFloat(weightStr);
            editor.putFloat("weight", weight);
            editor.putString("goal", spinnerGoal.getSelectedItem().toString());
            
            // Re-calculate BMI
            float height = sharedPreferences.getFloat("height", 170f);
            float bmi = weight / ((height / 100) * (height / 100));
            editor.putString("bmiCategory", getBMICategory(bmi));
            
            editor.apply();
            Toast.makeText(this, "Settings Updated!", Toast.LENGTH_SHORT).show();
            finish();
        });

        btnReset.setOnClickListener(v -> {
            sharedPreferences.edit().clear().apply();
            dbHelper.clearAllPlans();
            Intent intent = new Intent(this, ProfileActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });
    }

    private String getBMICategory(float bmi) {
        if (bmi < 18.5) return "Underweight";
        if (bmi < 25) return "Normal";
        if (bmi < 30) return "Overweight";
        return "Obese";
    }
}
