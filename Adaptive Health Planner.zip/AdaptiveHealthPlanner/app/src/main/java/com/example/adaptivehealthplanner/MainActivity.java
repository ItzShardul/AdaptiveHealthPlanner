package com.example.adaptivehealthplanner;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private SharedPreferences sharedPreferences;
    private DatabaseHelper dbHelper;
    private static final String CHANNEL_ID = "health_plan_channel";

    private ProgressBar pbCal, pbP, pbC, pbF;
    private TextView tvCalStatus, tvPStatus, tvCStatus, tvFStatus, tvNutrientAlert;
    private TextView tvBMIValue;
    private ImageView ivBMIChart;

    private ScaleGestureDetector scaleGestureDetector;
    private float mScaleFactor = 1.0f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sharedPreferences = getSharedPreferences("UserProfile", MODE_PRIVATE);
        dbHelper = new DatabaseHelper(this);

        TextView tvQuote = findViewById(R.id.tv_quote);
        pbCal = findViewById(R.id.pb_calories);
        pbP = findViewById(R.id.pb_protein);
        pbC = findViewById(R.id.pb_carbs);
        pbF = findViewById(R.id.pb_fat);
        
        tvCalStatus = findViewById(R.id.tv_calories_status);
        tvPStatus = findViewById(R.id.tv_p_status);
        tvCStatus = findViewById(R.id.tv_c_status);
        tvFStatus = findViewById(R.id.tv_f_status);
        tvNutrientAlert = findViewById(R.id.tv_nutrient_alert);
        tvBMIValue = findViewById(R.id.tv_bmi_value_display);
        ivBMIChart = findViewById(R.id.iv_bmi_chart);

        ImageButton btnBackToPage2 = findViewById(R.id.btn_back_to_page2);
        Button btnDetailedHistory = findViewById(R.id.btn_go_to_history);
        
        findViewById(R.id.btn_settings).setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));

        setupZoom();
        updateUI();

        String[] quotes = getResources().getStringArray(R.array.health_quotes);
        String randomQuote = quotes[new Random().nextInt(quotes.length)];
        tvQuote.setText(randomQuote);

        createNotificationChannel();

        btnDetailedHistory.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, DetailedHistoryActivity.class)));
        
        btnBackToPage2.setOnClickListener(v -> {
            Intent intent = new Intent(this, FoodSelectorActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(intent);
            finish();
        });
    }

    private void setupZoom() {
        scaleGestureDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                mScaleFactor *= detector.getScaleFactor();
                mScaleFactor = Math.max(0.5f, Math.min(mScaleFactor, 5.0f));
                ivBMIChart.setScaleX(mScaleFactor);
                ivBMIChart.setScaleY(mScaleFactor);
                return true;
            }
        });
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaleGestureDetector.onTouchEvent(event);
        return true;
    }

    private void updateUI() {
        String userName = sharedPreferences.getString("name", "User");
        String bmiStatus = sharedPreferences.getString("bmiCategory", "Normal");
        float bmiValue = sharedPreferences.getFloat("bmiValue", 0f);

        ((TextView)findViewById(R.id.tv_welcome)).setText("Welcome, " + userName + "!");
        ((TextView)findViewById(R.id.tv_bmi_badge)).setText("Status: " + bmiStatus);
        tvBMIValue.setText(String.format(Locale.US, "BMI: %.1f", bmiValue));
        
        String picUri = sharedPreferences.getString("profilePic", null);
        if (picUri != null) {
            try {
                ((ImageView)findViewById(R.id.iv_main_profile)).setImageURI(Uri.parse(picUri));
            } catch (SecurityException e) {
                ((ImageView)findViewById(R.id.iv_main_profile)).setImageResource(android.R.drawable.ic_menu_gallery);
            }
        }

        updateMacroProgress();
    }

    private void updateMacroProgress() {
        float weight = sharedPreferences.getFloat("weight", 70f);
        float height = sharedPreferences.getFloat("height", 170f);
        int age = sharedPreferences.getInt("age", 25);
        String gender = sharedPreferences.getString("gender", "Male");
        String goal = sharedPreferences.getString("goal", "Stay Fit");

        double bmr;
        if (gender.equals("Male")) {
            bmr = (10 * weight) + (6.25 * height) - (5 * age) + 5;
        } else if (gender.equals("Female")) {
            bmr = (10 * weight) + (6.25 * height) - (5 * age) - 161;
        } else {
            bmr = (10 * weight) + (6.25 * height) - (5 * age) - 78;
        }

        double tdee = bmr * 1.2;
        double targetCal = tdee;
        
        double pRatio = 0.25, cRatio = 0.50, fRatio = 0.25;
        if (goal.equals("Lose Weight")) {
            targetCal -= 500;
            pRatio = 0.40; cRatio = 0.40; fRatio = 0.20;
        } else if (goal.equals("Gain Muscle")) {
            targetCal += 300;
            pRatio = 0.30; cRatio = 0.40; fRatio = 0.30;
        }

        double targetP = (targetCal * pRatio) / 4;
        double targetC = (targetCal * cRatio) / 4;
        double targetF = (targetCal * fRatio) / 9;

        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        Cursor cursor = dbHelper.getDailyStats(today);
        float currentCal = 0, currentP = 0, currentC = 0, currentF = 0;
        if (cursor != null && cursor.moveToFirst()) {
            currentCal = cursor.getFloat(0);
            currentP = cursor.getFloat(1);
            currentC = cursor.getFloat(2);
            currentF = cursor.getFloat(3);
            cursor.close();
        }

        pbCal.setMax((int) targetCal);
        pbCal.setProgress((int) currentCal);
        tvCalStatus.setText(String.format(Locale.getDefault(), "Calories: %.0f / %.0f kcal", currentCal, targetCal));

        pbP.setMax((int) targetP); pbP.setProgress((int) currentP);
        tvPStatus.setText(String.format(Locale.getDefault(), "P: %.0fg / %.0fg", currentP, targetP));

        pbC.setMax((int) targetC); pbC.setProgress((int) currentC);
        tvCStatus.setText(String.format(Locale.getDefault(), "C: %.0fg / %.0fg", currentC, targetC));

        pbF.setMax((int) targetF); pbF.setProgress((int) currentF);
        tvFStatus.setText(String.format(Locale.getDefault(), "F: %.0fg / %.0fg", currentF, targetF));

        // Smart Nutrient Alerts
        StringBuilder alert = new StringBuilder();
        if (currentCal > targetCal) alert.append("⚠️ Calorie limit exceeded! ");
        if (currentP > targetP) alert.append("⚠️ Protein limit reached! ");
        if (currentC > targetC) alert.append("⚠️ High Carbs intake! ");
        if (currentF > targetF) alert.append("⚠️ Fats limit exceeded! ");

        if (alert.length() > 0) {
            tvNutrientAlert.setVisibility(View.VISIBLE);
            tvNutrientAlert.setText(alert.toString());
        } else {
            tvNutrientAlert.setVisibility(View.GONE);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Health Plan", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateUI();
    }
}
