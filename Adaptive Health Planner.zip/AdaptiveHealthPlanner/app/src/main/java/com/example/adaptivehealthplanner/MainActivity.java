package com.example.adaptivehealthplanner;

import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private SharedPreferences sharedPreferences;
    private DatabaseHelper dbHelper;
    private CheckBox cbLazyMode, cbCheatMeal;
    private static final String CHANNEL_ID = "health_plan_channel";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sharedPreferences = getSharedPreferences("UserProfile", MODE_PRIVATE);
        dbHelper = new DatabaseHelper(this);

        // UI References
        TextView tvWelcome = findViewById(R.id.tv_welcome);
        TextView tvBMIBadge = findViewById(R.id.tv_bmi_badge);
        TextView tvQuote = findViewById(R.id.tv_quote);
        TextView tvProgress = findViewById(R.id.tv_progress_tracker);
        ImageView ivProfile = findViewById(R.id.iv_main_profile);
        
        cbLazyMode = findViewById(R.id.cb_lazy_mode);
        cbCheatMeal = findViewById(R.id.cb_cheat_meal);
        
        Button btnGenerate = findViewById(R.id.btn_generate);
        Button btnHistory = findViewById(R.id.btn_view_history);
        
        // Navigation Buttons to Edit Profile
        ImageButton btnBackToProfile = findViewById(R.id.btn_back_to_profile);
        Button btnEditProfileBottom = findViewById(R.id.btn_edit_profile_bottom);
        
        findViewById(R.id.btn_settings).setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));

        // 1. Display User Info
        updateUI();

        // 2. Health Tip of the Day
        String[] quotes = getResources().getStringArray(R.array.health_quotes);
        String randomQuote = quotes[new Random().nextInt(quotes.length)];
        tvQuote.setText(randomQuote);

        createNotificationChannel();

        btnGenerate.setOnClickListener(v -> showConfirmDialog(randomQuote));

        btnHistory.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, HistoryActivity.class)));

        // Navigate to Profile for editing
        btnBackToProfile.setOnClickListener(v -> navigateToProfile());
        btnEditProfileBottom.setOnClickListener(v -> navigateToProfile());
    }

    private void updateUI() {
        TextView tvWelcome = findViewById(R.id.tv_welcome);
        TextView tvBMIBadge = findViewById(R.id.tv_bmi_badge);
        ImageView ivProfile = findViewById(R.id.iv_main_profile);
        TextView tvProgress = findViewById(R.id.tv_progress_tracker);

        String userName = sharedPreferences.getString("name", "User");
        String bmiStatus = sharedPreferences.getString("bmiCategory", "Normal");
        tvWelcome.setText("Welcome, " + userName + "!");
        tvBMIBadge.setText("Status: " + bmiStatus);
        
        String picUri = sharedPreferences.getString("profilePic", null);
        if (picUri != null) {
            ivProfile.setImageURI(Uri.parse(picUri));
        }

        Cursor cursor = dbHelper.getAllPlans();
        int count = (cursor != null) ? cursor.getCount() : 0;
        if (cursor != null) cursor.close();
        tvProgress.setText("You have completed " + count + " plans!");
    }

    private void navigateToProfile() {
        Intent intent = new Intent(MainActivity.this, ProfileActivity.class);
        intent.putExtra("edit_mode", true);
        startActivity(intent);
    }

    private void showConfirmDialog(String tip) {
        new AlertDialog.Builder(this)
                .setTitle("Generate Plan")
                .setMessage("Are you sure you want to generate your health plan?")
                .setPositiveButton("Yes", (dialog, which) -> generateAndSavePlan(tip))
                .setNegativeButton("No", null)
                .show();
    }

    private void generateAndSavePlan(String tip) {
        if (cbCheatMeal.isChecked()) {
            Toast.makeText(this, "Cheat Meal Warning: Don't overdo it!", Toast.LENGTH_LONG).show();
        }

        String goal = sharedPreferences.getString("goal", "Stay Fit");
        String foodPref = sharedPreferences.getString("foodPref", "Veg");
        float weight = sharedPreferences.getFloat("weight", 70f);

        String workout = generateWorkout(goal, cbLazyMode.isChecked());
        String diet = generateDiet(goal, foodPref, cbCheatMeal.isChecked());
        String water = calculateWater(weight);
        String date = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());

        dbHelper.insertPlan(date, diet, workout, water);

        sendNotification(tip);

        Intent intent = new Intent(MainActivity.this, ResultActivity.class);
        intent.putExtra("date", date);
        intent.putExtra("diet", diet);
        intent.putExtra("workout", workout);
        intent.putExtra("water", water);
        startActivity(intent);
    }

    private String generateWorkout(String goal, boolean lazy) {
        if (lazy) return "Light stretching and 15 min walk (Lazy Mode)";
        switch (goal) {
            case "Lose Weight": return "30 min Cardio (HIIT/Running)";
            case "Gain Muscle": return "45 min Strength Training (Weights)";
            default: return "20 min Yoga and Brisk Walking";
        }
    }

    private String generateDiet(String goal, String pref, boolean cheat) {
        String base = (pref.equals("Veg")) ? "Oats/Paneer/Dal" : "Eggs/Chicken/Fish";
        if (cheat) return "Cheat Day! Have a small portion of your favorite treat, but keep it balanced.";
        return "Breakfast: Fruit & " + base + ", Lunch: Brown Rice & Salad, Dinner: Soup & Grilled " + base;
    }

    private String calculateWater(float weight) {
        double liters = weight * 0.033;
        return String.format(Locale.getDefault(), "%.1f Liters per day", liters);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Health Plan", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void sendNotification(String tip) {
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Your Health Plan is Ready!")
                .setContentText("Tip: " + tip)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        try {
            notificationManager.notify(1, builder.build());
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateUI();
    }
}
