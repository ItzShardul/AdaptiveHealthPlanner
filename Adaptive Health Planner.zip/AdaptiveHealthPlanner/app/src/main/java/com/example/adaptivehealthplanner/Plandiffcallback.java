package com.example.adaptivehealthplanner;

import androidx.recyclerview.widget.DiffUtil;

import java.util.List;

public class Plandiffcallback extends DiffUtil.Callback {

    private final List<Healthplan> oldList;
    private final List<Healthplan> newList;

    public Plandiffcallback(List<Healthplan> oldList, List<Healthplan> newList) {
        this.oldList = oldList;
        this.newList = newList;
    }

    @Override
    public int getOldListSize() {
        return oldList.size();
    }

    @Override
    public int getNewListSize() {
        return newList.size();
    }

    @Override
    public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
        return oldList.get(oldItemPosition).id == newList.get(newItemPosition).id;
    }

    @Override
    public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
        return oldList.get(oldItemPosition).equals(newList.get(newItemPosition));
    }
}
