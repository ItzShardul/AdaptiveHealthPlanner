package com.example.adaptivehealthplanner;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * DatabaseHelper — changes needed for the RecyclerView + DiffUtil upgrade.
 *
 * KEY CHANGE: COLUMN_ID must be declared as a public constant so that
 * HistoryActivity can call cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID).
 *
 * Everything else (table name, other columns, insert/clear logic) is identical
 * to what you already have — only add the COLUMN_ID constant and make sure
 * _id is included in getAllPlans().
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME    = "health_planner.db";
    private static final int    DATABASE_VERSION  = 1;
    private static final String TABLE_PLANS       = "plans";

    // ── Column name constants (all public so HistoryActivity can reference them) ──
    public static final String COLUMN_ID      = "_id";     // ← ADD THIS if not present
    public static final String COLUMN_DATE    = "date";
    public static final String COLUMN_DIET    = "diet";
    public static final String COLUMN_WORKOUT = "workout";
    public static final String COLUMN_WATER   = "water";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE " + TABLE_PLANS + " ("
                        + COLUMN_ID      + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                        + COLUMN_DATE    + " TEXT, "
                        + COLUMN_DIET    + " TEXT, "
                        + COLUMN_WORKOUT + " TEXT, "
                        + COLUMN_WATER   + " TEXT"
                        + ")"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PLANS);
        onCreate(db);
    }

    public void insertPlan(String date, String diet, String workout, String water) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE,    date);
        values.put(COLUMN_DIET,    diet);
        values.put(COLUMN_WORKOUT, workout);
        values.put(COLUMN_WATER,   water);
        db.insert(TABLE_PLANS, null, values);
    }

    /**
     * KEY CHANGE: _id is now included in the projection.
     * The original query may have used SELECT * which also returns _id,
     * but explicit projection makes the intent clear and protects against
     * future schema changes breaking getColumnIndexOrThrow().
     *
     * Ordered newest-first so the most recent plan appears at the top.
     */
    public Cursor getAllPlans() {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(
                TABLE_PLANS,
                new String[]{ COLUMN_ID, COLUMN_DATE, COLUMN_DIET, COLUMN_WORKOUT, COLUMN_WATER },
                null, null, null, null,
                COLUMN_DATE + " DESC"   // newest first
        );
    }

    public void clearAllPlans() {
        getWritableDatabase().execSQL("DELETE FROM " + TABLE_PLANS);
    }
}