package com.example.adaptivehealthplanner;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "health_planner.db";
    private static final int DATABASE_VERSION = 4; // Incremented for schema/data stability
    private final Context context;

    public static final String TABLE_PLANS = "plans";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_DIET = "diet";
    public static final String COLUMN_WORKOUT = "workout";
    public static final String COLUMN_WATER = "water";

    public static final String TABLE_FOOD = "nutrition";
    public static final String COL_FOOD_ID = "id";
    public static final String COL_FOOD_NAME = "name";
    public static final String COL_CALORIES = "calories";
    public static final String COL_PROTEIN = "protiens_g";
    public static final String COL_CARBS = "carbs_g";
    public static final String COL_FAT = "fat_g";

    public static final String TABLE_LOGS = "daily_logs";
    public static final String COL_LOG_ID = "_id";
    public static final String COL_LOG_DATE = "log_date";
    public static final String COL_LOG_FOOD_ID = "food_id";
    public static final String COL_LOG_MEAL_TYPE = "meal_type";
    public static final String COL_LOG_CALORIES = "log_calories";
    public static final String COL_LOG_PROTEIN = "log_protein";
    public static final String COL_LOG_CARBS = "log_carbs";
    public static final String COL_LOG_FAT = "log_fat";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_PLANS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_DATE + " TEXT, " +
                COLUMN_DIET + " TEXT, " +
                COLUMN_WORKOUT + " TEXT, " +
                COLUMN_WATER + " TEXT)");

        db.execSQL("CREATE TABLE " + TABLE_FOOD + " (" +
                COL_FOOD_ID + " INTEGER PRIMARY KEY, " +
                COL_FOOD_NAME + " TEXT, " +
                COL_CALORIES + " REAL, " +
                COL_PROTEIN + " REAL, " +
                COL_CARBS + " REAL, " +
                COL_FAT + " REAL)");

        db.execSQL("CREATE TABLE " + TABLE_LOGS + " (" +
                COL_LOG_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_LOG_DATE + " TEXT, " +
                COL_LOG_FOOD_ID + " INTEGER, " +
                COL_LOG_MEAL_TYPE + " TEXT, " +
                COL_LOG_CALORIES + " REAL, " +
                COL_LOG_PROTEIN + " REAL, " +
                COL_LOG_CARBS + " REAL, " +
                COL_LOG_FAT + " REAL)");

        importCSV(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FOOD);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LOGS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PLANS);
        onCreate(db);
    }

    private void importCSV(SQLiteDatabase db) {
        try {
            InputStream is = context.getAssets().open("food.csv");
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            String line;
            reader.readLine();
            while ((line = reader.readLine()) != null) {
                String[] columns = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
                if (columns.length >= 6) {
                    ContentValues cv = new ContentValues();
                    cv.put(COL_FOOD_ID, columns[0].trim());
                    cv.put(COL_FOOD_NAME, columns[1].trim().replace("\"", ""));
                    cv.put(COL_CALORIES, parseSafe(columns[2]));
                    cv.put(COL_PROTEIN, parseSafe(columns[3]));
                    cv.put(COL_CARBS, parseSafe(columns[4]));
                    cv.put(COL_FAT, parseSafe(columns[5]));
                    db.insert(TABLE_FOOD, null, cv);
                }
            }
            reader.close();
        } catch (Exception e) {
            Log.e("DatabaseHelper", "Error importing CSV", e);
        }
    }

    private float parseSafe(String val) {
        try { return Float.parseFloat(val.trim()); } catch (Exception e) { return 0f; }
    }

    public void logFood(String date, int foodId, String mealType, float cal, float p, float c, float f) {
        SQLiteDatabase db = getWritableDatabase();
        // Fixed food logic: Only allow one entry per meal type per day to avoid duplication if user revisits page
        db.delete(TABLE_LOGS, COL_LOG_DATE + " = ? AND " + COL_LOG_MEAL_TYPE + " = ?", new String[]{date, mealType});
        
        ContentValues cv = new ContentValues();
        cv.put(COL_LOG_DATE, date);
        cv.put(COL_LOG_FOOD_ID, foodId);
        cv.put(COL_LOG_MEAL_TYPE, mealType);
        cv.put(COL_LOG_CALORIES, cal);
        cv.put(COL_LOG_PROTEIN, p);
        cv.put(COL_LOG_CARBS, c);
        cv.put(COL_LOG_FAT, f);
        db.insert(TABLE_LOGS, null, cv);
    }

    public void deleteLogsForDate(String date) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_LOGS, COL_LOG_DATE + " = ?", new String[]{date});
    }

    public Cursor getDailyStats(String date) {
        SQLiteDatabase db = getReadableDatabase();
        return db.rawQuery("SELECT SUM(" + COL_LOG_CALORIES + "), SUM(" + COL_LOG_PROTEIN + "), SUM(" + COL_LOG_CARBS + "), SUM(" + COL_LOG_FAT + ") FROM " + TABLE_LOGS + " WHERE " + COL_LOG_DATE + " = ?", new String[]{date});
    }

    public Cursor getLogsForDate(String date) {
        SQLiteDatabase db = getReadableDatabase();
        String query = "SELECT l." + COL_LOG_MEAL_TYPE + ", f." + COL_FOOD_NAME + ", l." + COL_LOG_CALORIES + 
                       ", l." + COL_LOG_PROTEIN + ", l." + COL_LOG_CARBS + ", l." + COL_LOG_FAT + 
                       " FROM " + TABLE_LOGS + " l JOIN " + TABLE_FOOD + " f ON l." + COL_LOG_FOOD_ID + " = f." + COL_FOOD_ID + 
                       " WHERE l." + COL_LOG_DATE + " = ? ORDER BY CASE " + COL_LOG_MEAL_TYPE + 
                       " WHEN 'Breakfast' THEN 1 WHEN 'Lunch' THEN 2 WHEN 'Dinner' THEN 3 ELSE 4 END";
        return db.rawQuery(query, new String[]{date});
    }

    // New: Fixed list of Indian Foods (Selection based on common Indian terms in your dataset)
    public Cursor getIndianFoodsFixed() {
        SQLiteDatabase db = getReadableDatabase();
        // Specifically selecting common Indian items from your CSV: Samosa, Paneer, Dhal, Sabzi, and Hindi names
        return db.rawQuery("SELECT * FROM " + TABLE_FOOD + 
                " WHERE " + COL_FOOD_NAME + " LIKE '%(%' " + // Items with Hindi names in brackets
                " OR " + COL_FOOD_NAME + " LIKE '%Paneer%'" +
                " OR " + COL_FOOD_NAME + " LIKE '%Dosa%'" +
                " OR " + COL_FOOD_NAME + " LIKE '%Lassi%'" +
                " OR " + COL_FOOD_NAME + " LIKE '%Samosa%'" +
                " ORDER BY " + COL_FOOD_NAME + " ASC LIMIT 150", null);
    }

    public void clearAllPlans() {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_PLANS, null, null);
        db.delete(TABLE_LOGS, null, null);
    }
}
