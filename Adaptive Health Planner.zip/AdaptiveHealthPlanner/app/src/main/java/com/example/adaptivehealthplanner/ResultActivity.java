package com.example.adaptivehealthplanner;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        TextView tvDiet = findViewById(R.id.tv_diet_res);
        TextView tvWorkout = findViewById(R.id.tv_workout_res);
        TextView tvWater = findViewById(R.id.tv_water_res);
        Button btnShare = findViewById(R.id.btn_share);
        Button btnBack = findViewById(R.id.btn_back);

        Intent intent = getIntent();
        String diet = intent.getStringExtra("diet");
        String workout = intent.getStringExtra("workout");
        String water = intent.getStringExtra("water");

        tvDiet.setText(diet);
        tvWorkout.setText(workout);
        tvWater.setText(water);

        btnShare.setOnClickListener(v -> {
            String shareBody = "My Health Plan for today:\n\n" +
                    "Diet: " + diet + "\n\n" +
                    "Workout: " + workout + "\n\n" +
                    "Water Intake: " + water;
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Adaptive Health Plan");
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareBody);
            startActivity(Intent.createChooser(shareIntent, "Share via"));
        });

        btnBack.setOnClickListener(v -> {
            Intent mainIntent = new Intent(ResultActivity.this, MainActivity.class);
            mainIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(mainIntent);
            finish();
        });
    }
}
